<?php
Session_start();
?>
<!DOCTYPE html>
<html>
    <head><title>Welcome to PHP</title></head>
        <body>
<form action="" method="post">
    <div class="form-group">
      <label for="email">Email address:</label>
      <input type="email" class="form-control" id="email">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" id="pwd">
    </div>
    <div class="checkbox">
      <label><input type="checkbox"> Remember me</label>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
  </form>
  </body>
</html>

<?php
include'connect.php';

$username = $conn->real_escape_string($_POST['Username']);
$password = $conn->real_escape_string($_POST['Password']);
 if (isset($_POST['submit'])) {

$sql = "SELECT id, firstname, lastname FROM MyGuest";
$result= $conn->query($sql);

if ($result->num_rows> 0) {
    while($row = $result-> fetch_assoc()) {
        $_SESSION['Username'] = $row['Username'];
        $_SESSION['Password'] = $row['Password'];
        ?>
        <script>alert("Successfully login!");</script>
        <?php
    }
    ?>
    <script><window.location.href='dashboard.php';</script>
    <?php
} else {
 ?>
 <script>alert("Incorrect username or password!")</script>
 <?php
}
}
$conn->close();
?> 