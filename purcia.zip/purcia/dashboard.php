<?php
  Session_start();
  if (!isset($_SESSION['Username'])) {
    header("Location: index.php");
    exit();
  }
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: "Lato", sans-serif;
  margin: 0;
}

.sidebar {
    height: 100%;
    width: 160px;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: grey;
    overflow-x: hidden;
    padding-top: 20px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
    transition: width 0.3s ease;
}

.sidebar a {
    padding: 12px 16px;
    text-decoration: none;
    font-size: 20px;
    color: #000;
    display: block;
    transition: background-color 0.3s ease;
}

.sidebar a:hover {
  background-color: rgba(255, 255, 255, 0.1);
}

.main {
  margin-left: 200px; 
  padding: 15px;
}

.sidebar a i {
  margin-right: 10px; 
}

.main {
  margin-left: 160px; 
  padding: 0px 10px;
  text-align: center;
}

@media screen and (max-height: 450px) {
  .sidebar {padding-top: 15px;}
  .sidebar a {font-size: 18px;}
}
.main-content {
  margin-left: 150px; 
  padding: 12px 16px;
   background-image: linear-gradient(to bottom, #95e6efcd, #69d6d1, #39cfe9);
  margin-top: -10px;
  margin-right: -10px;
}
.main-content a{
  text-decoration: none;
  color: #fff;
  font-size: 40px;
}
.main{
  display: flex;
  justify-content: space-between;
  text-align: center;
}
.main span{
  color: #fff;
}
.container{
  margin-left: 160px; 
  padding: 0px 10px;
  display: inline-block;
  margin-right: -65px;
  margin-left: 165px;
  
  
}
.card {
  height: 360px;
  width: 250px;
  background-image: linear-gradient(to bottom, #95e6efcd, #69d6d1, #39cfe9);
  margin: 7px;
  padding: 7px;
  border: 1px solid gray;
  border-radius: 5px;
  flex-direction: column;
  align-items: center;
  margin-right: -80px;
  margin-left: 30px;
  box-shadow: 5px 5px 10px rgba(0, 0, 0, 0.5);
  transition: transform 0.3s ease; /* Added transition */
}

.card-container {
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  margin-left: 5px;
}

.content input {
  border: none;
  background: transparent;
  font-size: 15px;
  width: 100%;
  margin: 3px;
  fill: none;
  text-align: center;
  display: block;
}




.add input{
  height: 40px;
  width: 100%;
  background:#ffffffd6;
  color: #101010;
  border: 1px solid teal;
  border-radius: 5px;

}
.add input[type="submit"]:hover {
  background-color: gray; 
  color: black; 
}
.img img{
  width: 250px;
  height: 250px;
  border-radius: 5px;
}
.align{
  display: inline-block;
}
.addProduct {
  margin-left: 160px;
  padding: 16px 10px;
  border-radius: 10px;
  
}

.addProduct button {
  height: 40px;
  width: 15%;
  background: gray;
  color: cyan; 
  border: 1px solid teal;
  border-radius: 5px;
}

.addProduct button:hover {
  background-color: white;
  color: black;
}

</style>
</head>
<body>

<div class="sidebar">
  <a href=dashboard.php><i class="fa fa-fw fa-home"></i> Product</a>
  <a href=services.php><i class="fa fa-fw fa-wrench"></i> Services</a>
  <a href=client.php><i class="fa fa-fw fa-user"></i> Clients</a>
  <a href=contact.php><i class="fa fa-fw fa-envelope"></i> Contact</a>
  <a href=logout.php><i class="fa fa-fw fa-lock"></i> Logout</a>
</div>

<div class="main main-content">
  <div class="main">
    <a href="">Welcome To petshop </a>
  </div>
  <span><h3>Welcome <?php echo $_SESSION['Name']; ?></h3></span>
</div>
<div class="addProduct">
<a href="addproduct.php"><button>Add Product</button></a>
</div>
<?php 
  include 'connect.php';

  $sql = "SELECT * FROM `product` ";
  $result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $pid = $row['Prod_Id'];
    $pname = $row['Prod_Name'];
    $pdesc = $row['Prod_desc'];
    $pprice = $row['Prod_price'];
    $pimg = $row['Prod_img'];

    ?>
    <div class="container">
  <div class="align">
    <div class="card">
      <div class="pid" hidden>
        <p><?php echo $pid; ?></p>
      </div>
      <div class="img">
        <img src="images/<?php echo $pimg; ?>" alt="">
      </div>
      <div class="content">
        <input type="text" name="Prod_Name" value="<?php echo $pname; ?>">
        <input type="text" name="Prod_desc" value="<?php echo $pdesc; ?>">
        <input type="text" name="Prod_price" value="&#8369;<?php echo $pprice; ?>">
      </div>
      <div class="add">
        <input type="submit" value="Add to cart">
      </div>
    </div>
  </div> 
</div>
<?php
  }
} else {
  echo "0 results";
}
$conn->close();
?>

     
</body>


</html> 

