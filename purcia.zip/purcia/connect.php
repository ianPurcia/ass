<?php
$servername = "localhost";
$userame = "root";
$password = "";
$db = "purcia";

$conn = new mysqli ($servername, $userame, $password, $db);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>