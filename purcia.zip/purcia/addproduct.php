<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    body {
		font-family: Arial, sans-serif;
       background-image: linear-gradient(to bottom, #95e6efcd, #69d6d1, #39cfe9);
      margin-top: 150px;
    }
    label {
      text-align: center; 
      display: block; 
    }
    h1 {
      text-align: center;
    }
    .border {
      border: 3px solid black;
      padding: 15px;
      width: 400px;
      margin: 50px auto;
      background-color: #ffffff; 
      border-radius: 30px;
      

    }
    input[type="text"],
    input[type="number"],
    input[type="file"] {
      width: calc(100% - 60px);
      border-radius: 5px;
      padding: 5px;
      box-sizing: border-box;
      margin-left: 30px;
      margin-right: 30px;
      margin-top: 10px;
      margin-bottom: 10px;
	  background-color: rgba(255, 255, 255, 0.8); 
    transition: border-color 0.3s ease;
    }


    button {
      width: calc(100% - 60px); 
      padding: 10px;
     background-color: #096f94;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      margin-left: 30px; 
      margin-right: 30px;
      margin-top: 15px; 
    }
    button:hover {
       background-color: #092e94;
    }
  </style>
</head>
<body>
  <div class="border">
    <h1>ADD PRODUCT</h1>
    <form action="" method="post" enctype="multipart/form-data">
      <label for="prod_name">Product Name:</label><br>
      <input type="text" id="prod_name" name="prod_name" required><br>
      <label for="prod_desc">Description:</label><br>
      <input type="text" id="prod_desc" name="prod_desc" required><br>
      <label for="prod_price">Price:</label><br>
      <input type="text" id="prod_price" name="prod_price" required><br>
      <label for="prod_img">Product Img:</label><br>
      <input type="file" id="prod_img" name="prod_img" required><br>
      <div class="btn-container">
        <button type="submit" name="submit">Add Product</button>
        <a href="dashboard.php"><button type="button">Back to Dashboard</button></a>
      </div>
    </form>
  </div>
</body>
</html>

<?php 
include 'connect.php';

if(isset($_POST['submit'])){
  $pname = $_POST['prod_name']; 
  $pdesc = $_POST['prod_desc'];
  $pprice = $_POST['prod_price'];

  // File upload handling
  $filename = $_FILES['prod_img']['name'];
  $filesize = $_FILES['prod_img']['size'];
  $tmpname = $_FILES['prod_img']['tmp_name'];

  $validImageExtensions = ['jpg', 'jpeg', 'png'];
  $imageExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

  if (!in_array($imageExtension, $validImageExtensions)){
    echo "<script>alert('Invalid Image Extension!')</script>";
  } else if ($filesize > 10000000){
    echo "<script>alert('The Image is too large!')</script>";
  } else {
    $newImageName = uniqid('', true) . '.' . $imageExtension;

    // Move uploaded file to destination directory
    if(move_uploaded_file($tmpname, 'images/' . $newImageName)) {
      // Prepare and execute SQL query
      $sql = "INSERT INTO product (Prod_Name, Prod_desc, Prod_price, Prod_img) 
              VALUES ('$pname', '$pdesc', '$pprice', '$newImageName')";

      if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Successfully Added!')</script>";
      } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
      }
    } else {
      echo "<script>alert('Failed to upload image!')</script>";
    }
  }
}
?>