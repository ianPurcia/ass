
<?php
include 'connect.php';


if(isset($_GET['del_Stu_id'])) {
   
    $del_Stu_id = $_GET['del_Stu_id'];

    
    $sql = "DELETE FROM `user` WHERE Stu_id='$del_Stu_id'";

    // Execute the DELETE query
    if ($conn->query($sql) === TRUE) {
       
        header("Location: client.php");
        exit();
    } else {
       
        echo "Error deleting record: " . $conn->error;
    }
} else {
    
    echo "Invalid request: 'del_Stu_id' parameter not set.";
}

// Close the database connection
$conn->close();
?>

