<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
    font-family: "Lato", sans-serif;
    margin: 0;
    padding: 0;
}

.sidebar {
    height: 100%;
    width: 160px;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    background-color: #111;
    overflow-x: hidden;
    padding-top: 16px;
}

.sidebar a {
    padding: 10px;
    text-decoration: none;
    font-size: 20px;
    color: #818181;
    display: block;
}

.sidebar a:hover {
    color: #f1f1f1;
}

.main {
    margin-left: 160px;
    padding: 20px;
}

table {
    width: 100%;
    border-collapse: collapse;
    background-color: #f3c9ea;
}

th, td {
    border: 1px solid black;
    padding: 8px;
    text-align: center;
}

th {
    background-color: #f2f2f2;
}

tr:hover {
    background-color: violet;
    text-align: center;
}

.btn {
    background-color: burlywood;
    color: white;
    padding: 8px 16px;
    border: none;
    cursor: pointer;
}

.btn:hover {
    background-color: brown;
}

.btn-edit {
    background-color: #28a745;
}

.btn-delete {
    background-color: #dc3545;
}
</style>
</head>
<body>

<div class="sidebar">
  <a href="dashboard.php"><i class="fa fa-fw fa-home"></i> Home</a>
  <a href="#services"><i class="fa fa-fw fa-wrench"></i> Services</a>
  <a href="client.php"><i class="fa fa-fw fa-user"></i> Clients</a>
  <a href="#contact"><i class="fa fa-fw fa-envelope"></i> Contact</a>
  <a href="logout.php"><i class="fa fa-fw fa-lock"></i> Logout</a>
</div>

<div class="main">
    <h2>List of Client</h2>
    <table>
        <tr>
            <th>Stu_id</th>
            <th>Name</th>
            <th>Address</th>
            <th>Username</th>
            <th>Password</th>
            <th colspan="2">Action</th>
        </tr>
    <?php
    include 'connect.php';
    $sql = "SELECT * FROM `user`";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $id = $row['Stud_id'];
            $name = $row['Name'];
            $address = $row['Address'];
            $username = $row['Username'];
            $password = $row['password'];
    ?>
        <tr>
            <td><?php echo $id; ?></td>
            <td><?php echo $name; ?></td>
            <td><?php echo $address; ?></td>
            <td><?php echo $username; ?></td>
            <td><?php echo $password; ?></td>
            <td><a href="update.php?stu_id=<?php echo $row['Stud_id'];?>"><button class="btn btn-edit">Edit</button></a></td>
            <td><button class="btn btn-delete" onclick="deleteme(<?php echo $row['Stud_id']; ?>)">Delete</button></td> 
        </tr>
        <script>
            function deleteme(delId) {
                if(confirm("Do you want to delete this record?")){
                    window.location.href='delete.php?del_Stu_id='+delId+ '';
                    return true;
                }
            }
        </script>
    <?php
        }
    } else {
        echo "<tr><td colspan='6'>0 results</td></tr>";
    }
    $conn->close();
    ?>
    </table>
</div>

</body>
</html>
