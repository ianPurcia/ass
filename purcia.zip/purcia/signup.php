<!DOCTYPE html>
<html>
<head>
    <title>document</title>
    <style>
         body {
    font-family: Arial, sans-serif;
    background-image: linear-gradient(to bottom, #95e6efcd, #69d6d1, #39cfe9);
}

.container {
    max-width: 400px;
    margin: 100px auto;
    background-color: #ffffff; 
    padding: 50px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
}

h1 {
    text-align: center;
    margin-bottom: 40px;
    color: #333; 
}

.form-group {
    margin-bottom: 30px;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 10px;
    font-size: 18px;
    color: #555; 
}

label a {
    color: #333; 
    text-decoration: none;
}

label a:hover {
    color: #096f94; 
}

input[type="name"],
input[type="address"],
input[type="email"],
input[type="password"] {
    width: calc(100% - 22px);
    padding: 12px; 
    border: 1px solid #555; 
    border-radius: 5px;
    font-size: 16px;
    background-color: rgba(255, 255, 255, 0.8); 
    transition: border-color 0.3s ease;
}

input[type="name"]:hover,
input[type="address"]:hover,
input[type="email"]:hover,
input[type="password"]:hover {
    border-color: #8f44f8;
}

.btn-container {
    text-align: center;
}

.btn {
    padding: 12px 25px; 
    background-color: #096f94;
    border: none;
    border-radius: 5px;
    color: #fff;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.btn:hover {
    background-color: #092e94;
}
    </style>
</head>
<body>
      <div class="container">

        <form action="" method="post">

        <h1>CREATE YOUR ACCOUNT</h1>

            <div class="form-group">
                <label for="name">Name:</label>
                <input type="name" class="form-control" id="name" name="Name" required>
            </div>
            <div class="form-group">
                <label for="address">Address:</label>
                <input type="address" class="form-control" id="address" name="Address" required>
            </div>
            <div class="form-group">
                <label for="email">Email address:</label>
                <input type="email" class="form-control" id="email" name="Username" required>
            </div>
            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" id="pwd" name="Password">
            </div>

            <div class="form-group">
            <div class="btn-container">
                <label><a href="index.php">Already have an account?</a></label>
            </div>
    </div>
            
            <div class="btn-container">
                <button type="submit" name="submit" class="btn">Register</button>
            </div>
        </form>
    </div>
</body>
</html>

<?php

include 'connect.php';

if (isset($_POST['submit'])){
    $name =$_POST['Name'];
    $address =$_POST['Address'];
    $username =$_POST['Username'];
    $password =$_POST['Password'];

    $sql ="INSERT INTO `user` (`Name`,`Address`,`Username`,`password`)
    VALUES('$name','$address','$username','$password')";

    if($conn->query($sql)== TRUE) {
        ?>
        <script>
        alert("Successfully Registered! Congrats!");
        window.location.href="index.php";
        </script>
        <?php
    }else{
        ?>
        <script>
        alert("error");
        </script>
        <?php
    }
    $conn->close();
}
?>
