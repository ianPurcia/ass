<?php 
Session_start();
Session_destroy();
header('location: index.php');
exit();
?>