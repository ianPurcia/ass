<!DOCTYPE html>
<html>
<head>
    <title>UPDATE</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: #f3c9ea;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        form {
            background: rgb(221, 144, 221);
            padding: 40px;
            border-radius: 8px;
            text-align: center;
            max-width: 300px;
            width: 100%;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            box-sizing: border-box; /* Added: Ensure padding doesn't affect width */
        }

        .checkbox {
            margin-top: 10px;
            text-align: left; /* Adjusted: Align checkbox label to left */
            text-align: center;
        }

        .btn-default {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            display: block;
            margin-top: 10px;
            text-align: center;
            margin-left: 110px;
        }

        .btn-default:hover {
            background-color: #0056b3;
            text-align: center;
        }
    </style>
</head>
 
<body>
<?php
include 'connect.php';
$sql = "SELECT * FROM user WHERE `Stu_id` = '".$_GET['Stu_id']."'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    $stu_id = $row['Stu_id'];
    $name = $row['Name'];
    $address = $row['Address'];
    $username = $row['Username'];
    $password = $row['Password'];
  }
 } else {
    echo "0 results";
 }
 $conn->close();
 ?>
    <form action="update.php?action=UpdateInfo&Stu_id=<?php echo $Stu_id; ?>" method="post">
    <h2>UPDATE</h2>
    <div class="form-group">
            <input type="hidden" id="Stu_id" name="Stu_id" value="<?php echo $stu_id; ?>" required>
        </div>
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="Name" value="<?php echo $name; ?>" required>
        </div>
        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" id="address" name="Address" value="<?php echo $address; ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email address:</label>
            <input type="email" id="email" name="Username" value="<?php echo $username; ?>" required>
        </div>
        <div class="form-group">
            <label for="pwd">Password</label>
            <input type="password" id="pwd" name="Password" value="<?php echo $password; ?>" required>
        </div>
        <div class="checkbox">
            <label><input type="checkbox"> Remember me</label>
        </div>
        <button type="submit" name="update" class="btn btn-default">Update</button>
    </form>
</body>
</html>
<?php
include 'connect.php';

if (isset($_POST['update'])) {
    $stu_id = isset($_GET['Stu_id']) ? $_GET['Stu_id'] : "";
    $action = isset($_GET['action']) ? $_GET['action'] : "";

    if ($action == 'UpdateInfo') {
        $name = $_POST['Name'];
        $address = $_POST['Address'];
        $username = $_POST['Username'];
        $password = $_POST['Password'];

        $sql = "UPDATE `user` SET `Name` = '$name', `Address` = '$address', `Username` = '$username', `Password` = '$password' WHERE `stu_id` = '$stu_id' ";

        if ($conn->query($sql) === TRUE) {
            ?><script>alert("Successfully Updated!");</script><?php
            header("refresh:.1");
           ?><script>Window.Location.href='client.php';</script><?php
            exit();
        } else {
            echo "Error updating record: " . $conn->error;
        }

        $conn->close();
    }
}
?>
