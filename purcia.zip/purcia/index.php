<?php
Session_start();
?>
<!DOCTYPE html>
<html>
    <head><title>Welcome to PHP</title>
    <style>
     body {
  margin: 0;
  padding: 0;
  background-image: linear-gradient(to bottom, #95e6efcd, #69d6d1, #39cfe9);
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  font-family: Arial, sans-serif; /* Added: Specify a fallback font */
}

form {
  max-width: 1000px; /* Adjusted: Reduced max-width for better readability */
  margin: 50px auto; /* Adjusted: Increased margin for spacing */
  background-color: #ffffff;
  padding: 40px;
  border-radius: 10px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.1); /* Adjusted: Increased box-shadow for depth */
}

.form-group {
  margin-bottom: 20px; /* Adjusted: Increased margin-bottom for spacing */
}

label {
  display: block;
  font-weight: bold;
  margin-bottom: 8px; /* Adjusted: Reduced margin-bottom for tighter spacing */
  color: #333; /* Added: Set label color to dark gray */
}

input[type="email"],
input[type="password"] {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 5px;
  font-size: 16px;
  transition: border-color 0.3s ease;
}

input[type="email"]:hover,
input[type="password"]:hover {
  border-color: #8f44f8;
}

.checkbox {
  margin-top: 10px;
}

.btn-default {
  padding: 12px 24px; /* Adjusted: Increased padding for better button size */
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  display: block;
  width: 100%; /* Adjusted: Set width to 100% for full-width button */
  margin-top: 20px; /* Adjusted: Increased margin-top for spacing */
  font-size: 16px; /* Added: Set font size for consistency */
}

.btn-default:hover {
  background-color: #0056b3;
}


      
      </style>
  </head>
        <body>
<form action="" method="post">
    <div class="form-group">
      <label for="email">Email address:</label>
      <input type="email" class="form-control" id="email" name="Username">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" name="Password">
    <div class="checkbox">
      <label><a href="signup.php"> Signup</a></label>
    </div>
    <button type="submit" name ="submit" class="btn btn-default">Submit</button>
  </form>
  </body>
</html>

<?php
include 'connect.php';

@$username = $conn->real_escape_string($_POST['Username']);
@$password = $conn->real_escape_string($_POST['Password']);
 if (isset($_POST['submit'])) {

$sql = "SELECT * FROM `user` WHERE `Username` ='$username' and `Password` ='$password' ";
$result= $conn->query($sql);

if ($result->num_rows> 0) {
    while($row = $result-> fetch_assoc()) {
        $_SESSION['Username'] = $row['Username'];
        $_SESSION['Password'] = $row['Password'];
        $_SESSION['Name']     = $row['Name'];
        ?>
        <script>alert("Successfully login!");</script>
        <?php
        ?>
        <script>window.location.href='dashboard.php';</script>
        <?php
    }
    
} else {
 ?>
 <script>alert("Incorrect username or password!")</script>
 <?php
}
}
$conn->close();
?> 